package board;

import java.io.Serializable;

public class Post implements Serializable {
	private static final long serialVersionUID = 1194316977528789177L;
	
	private int id;
	private String title;
	private String content;
	private String name;
	private String password;
	private int count;
	private String date;
	
	public Post(int id, String title, String content, String name, String password, int count, String date) {
		super();
		this.id = id;
		this.title = title;
		this.content = content;
		this.name = name;
		this.password = password;
		this.count = count;
		this.date = date;
	}

	public Post() {	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getDate() {
		return date;
	}

	public void setDate(String date) {
		this.date = date;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}
}
