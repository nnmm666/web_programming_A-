package board;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class PostDAO {
	public static DataSource getDataSource() throws NamingException {
		Context initCtx = null;
		Context envCtx = null;
		
		// Obtain our environment naming context
		initCtx = new InitialContext();
		envCtx = (Context) initCtx.lookup("java:comp/env");
		
		// Look up our data source
		return  (DataSource) envCtx.lookup("jdbc/WebDB");
	}
	
	public static PageResult<Post> getPage(int page, int numItemsInPage) throws SQLException, NamingException {
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		if(page <= 0) {
			page = 1;
		}
		
		DataSource ds = getDataSource();
		PageResult<Post> result = new PageResult<Post>(numItemsInPage, page);
		
		int startPos = (page - 1) * numItemsInPage;
		
		try {
			conn = ds.getConnection();
			
			// 총 게시글 개수 구하기 위한 부분 
			stmt = conn.prepareStatement("SELECT COUNT(*) FROM posts");
			rs = stmt.executeQuery();
			rs.next();
			
			result.setNumItems(rs.getInt(1));
			
			rs.close();
			stmt.close();
			rs = null;
			stmt = null;
			
			// 게시글 테이블 SELECT		
			stmt = conn.prepareStatement("SELECT * FROM posts ORDER BY id DESC LIMIT ?, ?");
			stmt.setInt(1, startPos);
			stmt.setInt(2, numItemsInPage);
			rs = stmt.executeQuery();
			
			while(rs.next()) {
				result.getList().add(
						new Post(rs.getInt("id"), rs.getString("title"), rs.getString("content"),
								rs.getString("name"), rs.getString("password"), rs.getInt("count"), rs.getString("date").substring(0, 10))
						);
			}
			
		} finally {
			if(rs != null) try {rs.close();} catch(SQLException e) {}
			if(stmt != null) try {stmt.close();} catch(SQLException e) {}
			if(conn != null) try {conn.close();} catch(SQLException e) {}
		}
		
		return result;
	}
	public static Post findById(int id) throws NamingException, SQLException {
		Post post = null;
		
		Connection conn = null;
		PreparedStatement stmt = null;
		ResultSet rs = null;
		
		DataSource ds = getDataSource();
		
		try {
			conn = ds.getConnection();
			stmt = conn.prepareStatement("SELECT * FROM posts WHERE id=?");
			stmt.setInt(1, id);
			rs = stmt.executeQuery();
			rs.next();
			
			post = new Post(rs.getInt("id"), rs.getString("title"), rs.getString("content").replaceAll("\n", "<br>"), 
					rs.getString("name"), rs.getString("password"), rs.getInt("count"), rs.getString("date").substring(0, 19));
			
		} finally {
			if(rs != null) try {rs.close();} catch(SQLException e) {}
			if(stmt != null) try {stmt.close();} catch(SQLException e) {}
			if(conn != null) try {conn.close();} catch(SQLException e) {}
		}
		
		return post;
	}
	
	public static boolean remove(int id) throws NamingException, SQLException {
		int result;
		Connection conn = null;
		PreparedStatement stmt = null;
		
		DataSource ds = getDataSource();
		
		try {
			conn = ds.getConnection();
			
			stmt = conn.prepareStatement("DELETE FROM posts WHERE id=?");
			stmt.setInt(1, id);
			result = stmt.executeUpdate();
			
		} finally {
			if(stmt != null) try {stmt.close();} catch(SQLException e) {}
			if(conn != null) try {conn.close();} catch(SQLException e) {}
		}
		
		return (result == 1);
	}
	
	public static boolean create(Post post) throws NamingException, SQLException {
		int result;
		Connection conn = null;
		PreparedStatement stmt = null;
		
		DataSource ds = getDataSource();
		
		
		
		try {
			conn = ds.getConnection();
			stmt = conn.prepareStatement("INSERT INTO posts (title, content, name, password)" +
					" VALUES (?, ?, ?, ?)");
			stmt.setString(1, post.getTitle());
			stmt.setString(2, post.getContent());
			stmt.setString(3, post.getName());
			stmt.setString(4, post.getPassword());
			
			result = stmt.executeUpdate();
		} finally {
			if(stmt != null) try {stmt.close();} catch(SQLException e) {}
			if(conn != null) try {conn.close();} catch(SQLException e) {}
		}
		
		return (result == 1);
	}

	public static boolean update(Post post) throws NamingException, SQLException {
		Connection conn = null;
		PreparedStatement stmt = null;
		int result;
		DataSource ds = getDataSource();
		
		try {
			conn = ds.getConnection();
			stmt = conn.prepareStatement("UPDATE posts SET title=?, content=?, name=?, password=?, count=? WHERE id=?");
			stmt.setString(1, post.getTitle());
			stmt.setString(2, post.getContent());
			stmt.setString(3, post.getName());
			stmt.setString(4, post.getPassword());
			stmt.setInt(5, post.getCount());
			stmt.setInt(6, post.getId());
			result = stmt.executeUpdate();
			
		} finally {
			if(stmt != null) try {stmt.close();} catch(SQLException e) {}
			if(conn != null) try {conn.close();} catch(SQLException e) {}
		}
		
		return (result == 1);
	}
}
