package servlet;

import java.io.IOException;
import java.sql.SQLException;
import javax.naming.NamingException;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import board.PageResult;
import board.Post;
import board.PostDAO;

/**
 * Servlet implementation class postServlet
 */
@WebServlet("/postServlet")
public class postServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public postServlet() {
        super();
    }

    private int getIntFromParameter(String str, int defaultValue) {
    	int id;
    	
    	try {
    		id = Integer.parseInt(str);
    	} catch (Exception e) {
    		id = defaultValue;
    	}
    	
    	return id;
    }
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		String op = request.getParameter("op");
		String actionUrl = "";
		
		int id = getIntFromParameter(request.getParameter("id"), -1);
		int page = getIntFromParameter(request.getParameter("page"), 1);
		if(op == null && id > 0) {
			op = "show";
		}
		try {
			if(op == null || op.equals("index")) {
				PageResult<Post> posts;
				posts = PostDAO.getPage(page, 10);
				request.setAttribute("posts", posts);
				request.setAttribute("page", page);
				actionUrl = "index.jsp";
				
			} else if(op.equals("signup")) {
				request.setAttribute("method", "signup");
				request.setAttribute("posts", new Post());
				actionUrl = "signup.jsp";
				
			} else if(op.equals("update")) {
				Post posts = PostDAO.findById(id);
				request.setAttribute("method", "update");
				request.setAttribute("posts", posts);
				actionUrl = "update.jsp";
				
			} else if(op.equals("show")) {
				Post posts = PostDAO.findById(id);
				posts.setCount(posts.getCount() + 1);
				PostDAO.update(posts);
				request.setAttribute("posts", posts);
				actionUrl = "show.jsp";
				
			} else if(op.equals("delete")) {
				PostDAO.remove(id);
				PageResult<Post> posts;
				posts = PostDAO.getPage(page, 10);
				request.setAttribute("posts", posts);
				request.setAttribute("page", page);
				actionUrl = "index.jsp";
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NamingException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		RequestDispatcher dispatcher = request.getRequestDispatcher(actionUrl);
		dispatcher.forward(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		request.setCharacterEncoding("utf-8");
		String actionUrl = "";
		Post post = new Post();
		boolean isRegisterMode = request.getParameter("operation").equals("update");
		
		String name = request.getParameter("name");
		String password = request.getParameter("password");
		String title = request.getParameter("title");
		String content = request.getParameter("content");
		int count = getIntFromParameter(request.getParameter("count"), 0);
		
		post.setId(getIntFromParameter(request.getParameter("id"), -1));
		post.setName(name);
		post.setPassword(password);
		post.setTitle(title);
		post.setContent(content);
		post.setCount(count);
		
		try {
			if(isRegisterMode)
				PostDAO.update(post);
			else
				PostDAO.create(post);
		} catch (NamingException | SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		actionUrl = "postServlet";		
		
		response.sendRedirect(actionUrl);
		
	}

}
